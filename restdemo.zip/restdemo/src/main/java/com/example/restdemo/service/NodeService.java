package com.example.restdemo.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.example.restdemo.domain.Node;

@Service
public class NodeService {

    private static final String ROOT_DIR = "D:/Chrysler";
    private static final String CUSTOM_SEPEARTOR = "^";

    private Path buildPath(String id) {
        Path root = Paths.get(ROOT_DIR);

        if (!StringUtils.isEmpty(id)) {
            String path = StringUtils.replace(id, CUSTOM_SEPEARTOR, File.separator);
            Path nodeRelativePath = Paths.get(path);
            Path nodePath = root.resolve(nodeRelativePath);
            if (Files.exists(nodePath)) {
                return nodePath;
            }
        }
        
        return root;
    }

    private String buildId(Path nodePath) {
        Path path = Paths.get(ROOT_DIR).relativize(nodePath);
        return StringUtils.replace(path.toString(), File.separator, CUSTOM_SEPEARTOR);
    }

    public List<Node> getNode(String id) {
        List<Node> nodes = new ArrayList<>();

        Path nodePath = buildPath(id);
        if (Files.exists(nodePath)) {
            try {
                Files.list(nodePath).forEach(path -> addNode(nodes, path));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return nodes;
    }

    private void addNode(List<Node> nodes, Path path) {
        File file = path.toFile();
        Node node = new Node(file.getName(), !file.isFile(), buildId(path), file.isFile() ? "file" : "folder");
        nodes.add(node);
    }

    public List<Node> getNode2(String id) {
        List<Node> nodes = new ArrayList<>();

        String dirPath = ROOT_DIR + File.separator + id;
        File dir = new File(dirPath);
        File[] files = dir.listFiles();
        if (files.length == 0) {
            System.out.println("The directory " + id + " is empty");
        } else {
            for (File aFile : files) {
                Node node = new Node(aFile.getName(), !aFile.isFile(), aFile.getPath(), aFile.isFile() ? "file" : "folder");
                nodes.add(node);
            }
        }
        //
        // Node node = new Node("1", true, "1", "folder");
        // nodes.add(node);
        //
        // node = new Node("tghghg", true, "tghghg", "folder");
        // nodes.add(node);

        return nodes;
    }
}
