package com.example.restdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.restdemo.domain.Node;
import com.example.restdemo.service.NodeService;

@RestController
public class NodeController {

    @Autowired
    private NodeService nodeService;

    @GetMapping("/getNode")
    public List<Node> greeting(@RequestParam(value = "id") String id) {
        return nodeService.getNode(id);
    }
}