package com.example.restdemo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class test {

    public static void main(String[] args) throws IOException {
        String dirPath = "D:/Chrysler";
//        File dir = new File(dirPath);
//        File[] files = dir.listFiles();
//        if (files.length == 0) {
//            System.out.println("The directory is empty");
//        } else {
//            for (File aFile : files) {
//                System.out.println("###########  Item = "+ aFile.getName() + "   ####################");
//                System.out.println(aFile.isFile());
//                System.out.println(aFile.getAbsolutePath());
//                System.out.println(aFile.getCanonicalPath());
//                System.out.println(aFile.getPath());
//            }
//        }
        
        Path paths = Paths.get(dirPath);
        Path child = Paths.get("Enhancements");
        System.out.println(child);
        
        Path rsolv = paths.resolve(child);
        System.out.println(rsolv);
        
        System.out.println(paths.relativize(rsolv));
        
        if (!Files.notExists(paths)) {
            Files.list(paths).forEach(path -> {
                System.out.println(path.getFileName());
                System.out.println(path);
                System.out.println(paths.resolve(path));
            });
        }
    }

}
