package com.example.restdemo.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Node {
    
    private final String text;
    private final boolean children;
    private final String id;
    private final String icon;
}
